import CustomEventFunc from "./customEvent.js";

const MainPageStru =
    `<div id="mainPage"> 
        <header class= "headerAllPages">
            <h1>Página Principal</h1>
        </header>   
        <div class= "allBtns">
            <button type="button" id="brigadeiro">Brigadeiros</button>
            <button type="button" id="cupcake">Cupcakes</button>
            <button type="button" id="doces">Doces</button>
        </div>
        <footer class ="footerAllPages">
            <p>Gabriela Rayla</p>
        </footer>
    </div>`;

export function MainPage(){
    
        
    
    return MainPageStru;
}

export function setupMainPage(){

    const root = document.getElementById("root");

    document.getElementById("brigadeiro").addEventListener("click", function(){
        // Brigadeiros();
        const brigadeirosUrl = CustomEventFunc("/brigadeiros");
        root.dispatchEvent(brigadeirosUrl);

    })
    document.getElementById("cupcake").addEventListener("click", function(){
        // Cupcake();
        const cupcakesUrl = CustomEventFunc("/cupcakes");
        root.dispatchEvent(cupcakesUrl);
    }) 
    document.getElementById("doces").addEventListener("click", function(){
        // Doces();
        const docesUrl = CustomEventFunc("/doces");
        root.dispatchEvent(docesUrl);
    }) 
}
import CustomEventFunc from "./customEvent.js";

const cupcakesStruc = `
    <div id="cupcakePage"> 
        <header class="headerAllPages">
            <p id="cupcakeDescrip">Página de cupcakes</p>
        </header>
        <div class= "allBtns">
            <button type="button" id="btnMainPage">Página principal</button> 
        </div>
        <footer class ="footerAllPages">
            <p>Gabriela Rayla</p>
        </footer>
    </div>`;

export function Cupcake(){
   

    
    return cupcakesStruc;
}

export function setupCupcake(){
    const root = document.getElementById("root");

    document.getElementById("btnMainPage").addEventListener("click", function(){
        // MainPage();
        const mainPageUrl = CustomEventFunc("/");
        root.dispatchEvent(mainPageUrl);
    })
}
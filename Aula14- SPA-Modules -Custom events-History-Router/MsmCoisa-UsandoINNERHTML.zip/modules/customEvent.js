export default function CustomEventFunc(url){
    

    const event =  new CustomEvent("onstatechange", {detail:{url: url}});
    // console.log(event, "eventoCriado");
    return event;
}
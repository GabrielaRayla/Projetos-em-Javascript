import CustomEventFunc from "./customEvent.js";

const brigadeiroStruc = `
    <div id="brigadeiroPage"> 
        <header class="headerAllPages">
            <p id="brigadeiroDescrip">Página de brigadeiros</p>
        </header>
        <div class= "allBtns">
            <button type="button" id="btnMainPage">Página principal</button> 
        </div>
        <footer class ="footerAllPages">
            <p>Gabriela Rayla</p>
        </footer>
    </div>`;

export function Brigadeiros(){
    
    
    
    return brigadeiroStruc;
}

export function setupBrigadeiros(){
    const root = document.getElementById("root");

    document.getElementById("btnMainPage").addEventListener("click", function(){
        // MainPage();
        const mainPageUrl = CustomEventFunc("/");
        root.dispatchEvent(mainPageUrl);
    })
}
import {MainPage, setupMainPage} from "./mainPage.js";
import {Brigadeiros, setupBrigadeiros} from "./brigadeiros.js";
import {Cupcake, setupCupcake} from "./cupcake.js";
import {Doces, setupDoces} from "./doces.js";
// import CustomEventFunc from "./customEvent.js";

export default function routerFunc(){
    const router = {
        "/": MainPage,   
        "/brigadeiros" : Brigadeiros,
        "/cupcakes" : Cupcake,
        "/doces": Doces,


        getPage: function(url){
            switch(url){
                case "/":
                    return router["/"]();
                case "/brigadeiros":
                    return router["/brigadeiros"]();
                    
                case "/cupcakes":
                    return router["/cupcakes"]();
                   
                case "/doces":
                    return router["/doces"]();
                       
            }
            // 
        },
        setup: function(url){
            switch(url){
                case "/":
                    setupMainPage();
                case "/brigadeiros":
                    setupBrigadeiros();
                    
                case "/cupcakes":
                    setupCupcake();
                   
                case "/doces":
                    setupDoces();
                       
            }
            // 
        }
    }
    return router;
}
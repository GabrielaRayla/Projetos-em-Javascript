import routerFunc from "./modules/router.js";

// MainPage();      

// f - salvar o objeto de rotas retornado numa constante
const router = routerFunc();
console.log(router, "router");

const root = document.getElementById("root");
root.addEventListener("onstatechange", function(event){
    const url = event.detail.url;
    console.log(url, "url");
    // errro ao pegar o valor (dá undefined), e erro ao colocar page com inner HTML justamente por isso
    const page = router.getPage(url);
    
    root.innerHTML = page;
    router.setup(url);

    console.log(page, "nhauu");
   
    // erro ao recarregar a página
    history.pushState("", "", event.detail.url);  
})

root.innerHTML = router.getPage("/");
router.setup("/");

